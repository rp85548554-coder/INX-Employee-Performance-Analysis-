# Notebook run order

1. `Data_Processing/data_processing.ipynb`
2. `Data_Processing/data_exploratory_analysis.ipynb`
3. `models/train_model.ipynb`
4. `models/predict_model.ipynb`
5. `visualization/visualize.ipynb`

Run from the project root so the relative folder structure can be discovered. The notebooks include markdown explanations and comments. The official dataset is required before execution.
