# Submission Checklist

- [ ] Official dataset is in `data/raw/`; original file remains unchanged.
- [ ] All five notebooks run from top to bottom without errors.
- [ ] Data processing summary and EDA findings have been reviewed.
- [ ] Department-wise results are based on actual output.
- [ ] Top three features are copied from permutation importance results.
- [ ] Model comparison, confusion matrix, and classification report are reviewed.
- [ ] Final summary contains actual metrics, not placeholders.
- [ ] Notebook markdown explains the decisions and limitations.
- [ ] No fabricated data or invented performance metrics are included.
- [ ] Confirm submission portal and deadline in the assignment email.
