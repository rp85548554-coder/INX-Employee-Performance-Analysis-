# Data Dictionary Template

After loading the official data, document each column below.

| Column name | Meaning from source documentation | Data type | Missing values | Notes |
|---|---|---|---:|---|
| _Populate from official dataset_ | | | | |

Do not guess column definitions. Use the official data dictionary or source documentation where available.
