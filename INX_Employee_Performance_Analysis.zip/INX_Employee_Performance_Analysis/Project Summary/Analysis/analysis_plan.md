# Analysis Plan

1. Load the official dataset and document its shape and schema.
2. Check missing values, duplicate records, data types, and target distribution.
3. Remove exact duplicates; exclude missing target values from supervised learning.
4. Analyze performance distribution and department-wise averages where the department field is available.
5. Split train/test data with a fixed random seed and stratification when feasible.
6. Impute and encode features inside a pipeline to avoid leakage.
7. Compare Logistic Regression, Decision Tree, Random Forest, Extra Trees, and SVM.
8. Select the candidate with highest weighted F1, using accuracy as tie-breaker.
9. Report precision, recall, F1, confusion matrix, and permutation feature importance.
10. Convert results into recommendations; avoid causal claims unless supported by a suitable design.
