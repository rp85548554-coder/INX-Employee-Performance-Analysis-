# Project Requirements

## Business context
INX Future Inc. reports declining employee performance indicators and an 8 percentage-point decline in client satisfaction. The goal is to analyze employee data and support evidence-based actions.

## Required insights
1. Department-wise performance.
2. Three most important factors associated with model prediction.
3. A trained machine-learning model that predicts employee performance from input factors.
4. Recommendations based on the analysis.

## Deliverables
- Jupyter notebooks with markdown explanations and commented code.
- Data cleaning and exploratory analysis.
- Model comparison and evaluation.
- Prediction notebook.
- Visualizations and final summary.
- Reproducible directory structure.
