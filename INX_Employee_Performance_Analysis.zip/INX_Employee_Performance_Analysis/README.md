# INX Future Inc. Employee Performance Analysis

IABAC Project Code 10281 — reproducible notebook-based project scaffold.

## Important dataset note
The project brief was available, but the dataset file itself was not attached to the current chat at the time this package was assembled, and the IABAC data URL could not be retrieved automatically. **Place the official dataset in `data/raw/` before running the notebooks.** Do not use synthetic data for final results.

## Setup
1. Install Python 3.10+.
2. Create/activate a virtual environment if desired.
3. Install dependencies: `pip install -r requirements.txt`
4. Place the official `.xls`, `.xlsx`, or `.csv` dataset in `data/raw/`.
5. Open Jupyter from the project root: `jupyter notebook`
6. Run notebooks in this order:
   - `src/Data_Processing/data_processing.ipynb`
   - `src/Data_Processing/data_exploratory_analysis.ipynb`
   - `src/models/train_model.ipynb`
   - `src/models/predict_model.ipynb`
   - `src/visualization/visualize.ipynb`

## Expected business deliverables
1. Department-wise performance analysis (if department field exists).
2. Top three predictive features using permutation importance.
3. Evaluated classification pipeline to predict `PerformanceRating`.
4. Data-supported recommendations.

## Notes
- Target detection searches for `PerformanceRating`, `Performance_Rating`, or `Performance`. If your file uses a different name, update the target selection in the notebooks.
- Exact duplicate rows are removed. Missing feature values are handled inside the modelling pipeline.
- Employee identifiers are excluded from modelling when their names match common ID columns. Review this if the official schema uses a different identifier.
- Results and metrics are generated only after running the notebooks on the official data.
- Predictions should support, not replace, fair human review in employment decisions.


## Dataset setup

The `data_processing.ipynb` notebook tries to download the official IABAC `.xls` dataset automatically if `data/raw/` is empty. If your network blocks downloads, download the file from the official source listed in `data/raw/PUT_OFFICIAL_DATASET_HERE.txt` and place it in `data/raw/`.
